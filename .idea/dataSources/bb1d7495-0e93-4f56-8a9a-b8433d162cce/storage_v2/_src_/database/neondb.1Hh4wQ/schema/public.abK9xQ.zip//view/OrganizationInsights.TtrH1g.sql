create view "OrganizationInsights"("organizationId", "organizationName", "organizationCreatedAt", "videoCount", "analyzedVideoCount", "processingVideoCount", "observationCount", "observationsLast7d", "observationsLast30d", "lastObservationAt", "patternCount", "confirmedPatternCount", "emergingPatternCount", "fadingPatternCount", "avgConfidence", "avgPerformanceLift", "entityCount", "ideaBatchCount", "ideaCount", "memberCount") as
	SELECT o.id AS "organizationId",
    o.name AS "organizationName",
    o."createdAt" AS "organizationCreatedAt",
    vids."videoCount",
    vids."analyzedVideoCount",
    vids."processingVideoCount",
    obs."observationCount",
    obs."observationsLast7d",
    obs."observationsLast30d",
    obs."lastObservationAt",
    pats."patternCount",
    pats."confirmedPatternCount",
    pats."emergingPatternCount",
    pats."fadingPatternCount",
    pats."avgConfidence",
    pats."avgPerformanceLift",
    ents."entityCount",
    ideas."ideaBatchCount",
    ideas."ideaCount",
    mem."memberCount"
   FROM "Organization" o
     LEFT JOIN LATERAL ( SELECT count(*)::integer AS "videoCount",
            count(*) FILTER (WHERE v.status = 'ANALYZED'::"VideoStatus")::integer AS "analyzedVideoCount",
            count(*) FILTER (WHERE v.status = ANY (ARRAY['PENDING'::"VideoStatus", 'PROCESSING'::"VideoStatus"]))::integer AS "processingVideoCount"
           FROM "Video" v
          WHERE v."organizationId" = o.id) vids ON true
     LEFT JOIN LATERAL ( SELECT count(*)::integer AS "observationCount",
            count(*) FILTER (WHERE ob."createdAt" >= (now() - '7 days'::interval))::integer AS "observationsLast7d",
            count(*) FILTER (WHERE ob."createdAt" >= (now() - '30 days'::interval))::integer AS "observationsLast30d",
            max(ob."createdAt") AS "lastObservationAt"
           FROM "Observation" ob
          WHERE ob."organizationId" = o.id) obs ON true
     LEFT JOIN LATERAL ( SELECT count(*)::integer AS "patternCount",
            count(*) FILTER (WHERE p.status = 'CONFIRMED'::"PatternStatus")::integer AS "confirmedPatternCount",
            count(*) FILTER (WHERE p.status = 'EMERGING'::"PatternStatus")::integer AS "emergingPatternCount",
            count(*) FILTER (WHERE p.status = 'FADING'::"PatternStatus")::integer AS "fadingPatternCount",
            avg(p.confidence)::double precision AS "avgConfidence",
            avg(p."performanceLift") AS "avgPerformanceLift"
           FROM "Pattern" p
          WHERE p."organizationId" = o.id) pats ON true
     LEFT JOIN LATERAL ( SELECT count(*)::integer AS "entityCount"
           FROM "Entity" e
          WHERE e."organizationId" = o.id) ents ON true
     LEFT JOIN LATERAL ( SELECT count(DISTINCT ib.id)::integer AS "ideaBatchCount",
            count(vi.id)::integer AS "ideaCount"
           FROM "IdeaBatch" ib
             LEFT JOIN "VideoIdea" vi ON vi."batchId" = ib.id
          WHERE ib."organizationId" = o.id) ideas ON true
     LEFT JOIN LATERAL ( SELECT count(*)::integer AS "memberCount"
           FROM "Member" m
          WHERE m."organizationId" = o.id) mem ON true;

alter table "OrganizationInsights" owner to neondb_owner;

